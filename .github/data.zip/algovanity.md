> This resource is auto indexed by AwesomeAlgo, all credits to algovanity, for more details refer to https://github.com/Ripe/algovanity

---

# Algorand Vanity Address Generator

Source code for https://algovanity.com

### Prerequisites

- Git
- Node.js

### Quick start

```
git clone https://github.com/Ripe/algovanity
cd algovanity
npm i
npm run dev
```

### License

Licensed under a MIT license. See the [LICENSE](LICENSE) file for details.
