> This resource is auto indexed by AwesomeAlgo, all credits to walletconnect-example-dapp, for more details refer to https://github.com/algorand/walletconnect-example-dapp

---

# WalletConnect Example Dapp

## Develop

```bash
npm run start
```

## Test

```bash
npm run test
```

## Build

```bash
npm run build
```
